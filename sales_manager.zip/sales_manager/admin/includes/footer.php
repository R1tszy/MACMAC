<footer class="footer">
    <p>&copy; <?php echo date("Y"); ?> HELP LORD. All Rights Reserved.</p>
</footer>

<style>
    .footer {
        text-align: center;
        padding: 15px;
        background-color: #333;
        color: white;
        position: sticky;
        bottom: 0;
        width: 100%;
    }
</style>

</body>
</html>
