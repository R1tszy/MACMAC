<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['staff_id'])) {
    session_destroy();

    header("Cache-Control: no-cache, must-revalidate, no-store, max-age=0");
    header("Pragma: no-cache");
    header("Expires: 0");

    header("Location: login.php");
    exit();
}
?>
