<?php
session_start();
require '../db_connect.php';

if (isset($_GET['id']) && isset($_GET['action'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];

    // current stock
    $product = $conn->query("SELECT stock FROM products WHERE id = $id")->fetch_assoc();
    if (!$product) {
        header("Location: inventory.php?error=notfound");
        exit();
    }

    $current_stock = $product['stock'];

    if ($action == "subtract") {
        if ($current_stock > 0) {
            $new_stock = $current_stock - 1;
        } else {
            header("Location: inventory.php?error=outofstock");
            exit();
        }
    } elseif ($action == "add") {
        $new_stock = $current_stock + 1;
    } else {
        header("Location: inventory.php?error=invalidaction");
        exit();
    }

    // Upd stock
    $update = $conn->query("UPDATE products SET stock = $new_stock WHERE id = $id");

    if ($update) {
        header("Location: inventory.php?success=updated");
    } else {
        header("Location: inventory.php?error=updatefailed");
    }
}
?>
